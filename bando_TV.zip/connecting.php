<?php
$servername = "SG-WebsiteTV01-10984-mysql-master.servers.mongodirector.com";
$username = "sgroot";  // Tên đăng nhập mặc định của XAMPP
$password = "GmR9t2uE@hk3ukNo";      // Mật khẩu mặc định để trống
$database = "doan"; // Thay đổi tên database của bạn

// Tạo kết nối
$conn = mysqli_connect($servername, $username, $password, $database);

// Kiểm tra kết nối

?>